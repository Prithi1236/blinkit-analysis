# scripts/enrich_instacart_to_blinkit.py
# Simple script (already run in this workspace) that enriches CSVs.
import pandas as pd

print('This repo includes sample enriched CSVs in /data.')
