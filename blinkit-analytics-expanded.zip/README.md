# Blinkit Analytics - Sample Project

This repository contains a complete, **hire-ready** Blinkit-like analytics project with sample data, SQL, Python notebooks, and instructions to reproduce analyses and Power BI visuals.

**Contents**
- data/: sample CSVs (customers, products, dark stores, orders, order_items)
- notebooks/: Jupyter notebooks for EDA, forecasting, and association rules
- sql/: DDL and analysis queries
- scripts/: helper scripts
- powerbi/: instructions and placeholders for a PBIX (Power BI) file
- presentation/: sample PPTX/PDF placeholder

**How to use**
1. Install Python dependencies (see requirements.txt).
2. Open notebooks in JupyterLab / VS Code and run cells.
3. Import CSVs into your SQL database (Postgres / BigQuery) using the SQL DDL in sql/ddl_tables.sql.
4. Build Power BI report using the CSVs or a connection to your DB. See 'powerbi/README_powerbi.md' for guidance.

**Important:** These CSVs are synthetic and meant for demo/portfolio use only.

Generated on: 2025-09-28T20:58:17.907203 UTC
